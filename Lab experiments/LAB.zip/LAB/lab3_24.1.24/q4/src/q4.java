public class q4 {
    static int isPrime() {  // Added 'int n' (bug: unnecessary parameter)
        int count = 0;
        for (int i = 2; i <= 1000; i++) {
            boolean flag = true;
            for (int j = 2; j <= Math.sqrt(i); j++) {  // Bug: Should start from 2, not 1
                if (i % j == 0) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        System.out.println(isPrime());  // Bug: Missing argument
    }
}

