
//4.	Write a Java program to count and display the total number of prime numbers between 1 and 1000.

public class q4 {
    
}
