//1.	Write a program to calculate the sum of all integers between 10 and 950
//that are divisible by both 6 and 9.

public class q1 {
    static int sum_of_numbers(){
        int sum = 0;
        for (int i=10; i<=950; i++){
            if (i%6==0 && i%9==0){
                sum += i;
            }
        }
        return sum;

    }
    public static void main(String[] args){
        int x = sum_of_numbers();
        System.out.println("The sum is " + x);
    }
}
