//3.Write a Java program that prints the first N terms of the Fibonacci series using a loop.

import java.util.Scanner; 
public class q3 {

    static int fibionacci(int n){
            int pehla = 0, dusra = 1, teesra, sum = 0;
            System.out.print("Fibonacci series: ");
        
            if (n >= 1) {
                System.out.print(pehla);
                sum += pehla;
            }
            if (n >= 2) {
                System.out.print(", " + dusra);
                sum += dusra;
            }
        
            for (int i = 3; i <= n; i++) {
                teesra = pehla + dusra;
                System.out.print(", " + teesra);
                sum += teesra;
                pehla = dusra;
                dusra = teesra;
            }
        
            System.out.println();
            return sum;
        }

    public static void main(String[] args) {
        Scanner range = new Scanner(System.in); 
        System.out.print("Enter the limit of the fibionacci series: ");
        int number = range.nextInt();
        int answer = fibionacci(number);

        System.out.println("The sum of the digits is: " + answer);

        range.close(); // Close the scanner to free resources
    }
}

