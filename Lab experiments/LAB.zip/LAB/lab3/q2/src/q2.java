//2.	Write a Java program that takes an integer as input and calculates 
//the sum of its digits using a while loop.

import java.util.Scanner; 


public class q2 {

    
    int sum = 0;

    static int addition(int x){
        int sum = 0;
        while (x != 0) {
            int digit = x % 10; 
            sum += digit;       
            x /= 10;           
        }
        return sum;
    }
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in); 

        System.out.print("Enter an integer: ");
        int number = num.nextInt();
        int answer = addition(number);
        System.out.println("The sum of the digits is: " + answer);
        num.close(); // Close the scanner to free resources
    }
}
