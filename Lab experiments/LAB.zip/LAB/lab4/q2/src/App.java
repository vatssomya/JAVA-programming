import java.util.Scanner;
//bank account class
class BankAccount {
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }
//deposit system
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("deposited: " + amount);
        } else {
            System.out.println("invalid deposit amount");
        }
    }
 //withdrawl system
    protected void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("withdrew: " + amount);
        } else {
            System.out.println("invalid withdraw amount or insufficient balance");
        }
    }
 //check balance
    void checkBalance() {
        System.out.println("current balance: " + balance);
    }

    public double getBalance() {
        return balance;
    }
}

public class Exp4_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("initial balance: ");
        double initialBalance = scanner.nextDouble();

        BankAccount account = new BankAccount(initialBalance);

        System.out.print("deposit amount: ");
        double depositAmount = scanner.nextDouble();
        account.deposit(depositAmount);

        System.out.print("withdrawal amount: ");
        double withdrawalAmount = scanner.nextDouble();
        account.withdraw(withdrawalAmount);

        account.checkBalance();

        scanner.close();
    }
}