class Student {
    static String universityName; //constant uiversity name for all
    String studentName;

    public Student(String studentName) { //parameterized constructor
        this.studentName = studentName;
    }
    static void displayUniversityName() {
        System.out.println("University Name: " + universityName);
    }
    void displayStudentName() {
        System.out.println("Student Name: " + studentName);
    }
}

public class Exp4_3 {
    public static void main(String[] args) {
        Student.universityName = "University of Petrolium and Energy Sciences";

        
        Student student1 = new Student("Shivam");
        Student student2 = new Student("Chaitanya");
        Student student3 = new Student("Saakshi");
        Student.displayUniversityName();

        student1.displayStudentName();
        student2.displayStudentName();
        student3.displayStudentName();
    }
}