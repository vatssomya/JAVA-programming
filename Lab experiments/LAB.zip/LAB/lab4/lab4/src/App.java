class Student { //class named student
    String name;
    int age;
    int rollNo;
    int sapID;
    public Student() {
        this.name = "Shivam";
        this.age = 21;
        this.rollNo = 1234;
        this.sapID = 500060209;
    }
    public Student(String name, int age) { //parameterized constructor
        this.name = name;
        this.age = age;
        this.rollNo = 1234;
        this.sapID = 500060209;
    }
    public void display() { //display function
        System.out.println("Student name: " + name);
        System.out.println("Student age: " + age);
        System.out.println("Student rollno: " + rollNo);
        System.out.println("Student rollno: " + sapID);
    }

    public static void main(String[] args) { //main function
        Student student1 = new Student();
        System.out.println("Default Constructor:");
        student1.display();

        System.out.println();

        Student student2 = new Student("Somya", 20);


        System.out.println("Parameterized constructor:");
        student2.display();
    }
}
