public class q3again {
    static void calculator(int x, String operator, int y) {
        if (operator.equals("x") || operator.equals("mul")) {
            operator = "*";
        }

        switch (operator) {
            case "+":
                System.out.println("Sum of " + x + " and " + y + " is " + (x + y));
                break;
            case "-":
                System.out.println("Difference of " + x + " and " + y + " is " + (x - y));
                break;
            case "*":
                System.out.println("Product of " + x + " and " + y + " is " + (x * y));
                break;
            default:
                System.out.println("Invalid operator");
        }
    }

    public static void main(String[] args) {
        int x = Integer.parseInt(args[0]);
        String operator = args[1];
        int y = Integer.parseInt(args[2]);

        calculator(x, operator, y);
    }
}
