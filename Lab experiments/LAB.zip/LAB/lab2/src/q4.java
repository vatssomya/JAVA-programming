/*4. Write a Java program to check whether a given number is positive, negative, or zero
using an if-else statement.

*/
public class q4 {
    
}
