public class q1 {

    static double area_triangle(double base, double height){
        return (base * height) / 2;
    }
    public static void main(String[] args) throws Exception {

        double x1 = 3;
        double x2 = 4;
        double x3 = 5;
        double x4 = 6;

        double area1 = area_triangle(x1, x2);
        double area2 = area_triangle(x3, x4);
        System.out.println("Area of triangle 1: " +area1);
        System.out.println("Area of triangle 2: " +area2);
        
    }
}
