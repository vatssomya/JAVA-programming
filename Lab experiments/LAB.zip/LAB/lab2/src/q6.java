/*6. Create a program that accepts a number (1–7) and displays the corresponding day of
the week using a switch statement.public class q6 {
    
}
*/