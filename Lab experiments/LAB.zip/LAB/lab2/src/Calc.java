/*Write a program to implement a command line calculator. (Try for Add sub Mul in same
program for 2 digits.)
(Hint: Integer.parseInt will be used)
For e.g. java calc 20 + 30
Output should be Sum of 20 and 30 is 50

public class q3 {
        public static void main(String[] args) throws Exception {
        

            System.out.println("Usage: java Calc <num1> <operator> <num2>");
            try {
                String num1 = args[0];
                String operator = args[1];
                String num2 = args[2];
                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);
                int result = 0;
                switch (operator) {
                    case "+":
                    result = a + b;
                    System.out.println("Output is the Sum of " + a + " and " + b + " is "+ result);
                    break;
                    case "-":
                    result = a - b;
                    System.out.println("Difference of " + a + " and " + b + " is " + result);
                    break;
                    case "*":
                    result = a * b;
                    System.out.println("Product of " + a + " and " + b + " is " + result);
                    default:
                    System.out.println("Invalid operator! Use +, -, or *.");
                    }
            }catch(NumberFormatException e){
                System.out.println("Error: Please enter valid integers for <num1> and <num2>.");
        }
    }
}
 */



public class Calc {
    public static void main(String[] args) {
        // Check if 3 arguments are provided
        if (args.length != 3) {
            System.out.println("Usage: java Calc <num1> <operator> <num2>");
            return;
        }

        try {
            // Parse the arguments
            int num1 = Integer.parseInt(args[0]); // First number
            String operator = args[1];           // Operator (+, -, *)
            int num2 = Integer.parseInt(args[2]); // Second number

            // Perform the operation
            switch (operator) {
                case "+":
                    System.out.println("Sum of " + num1 + " and " + num2 + " is " + (num1 + num2));
                    break;
                case "-":
                    System.out.println("Difference of " + num1 + " and " + num2 + " is " + (num1 - num2));
                    break;
                case "*":
                    System.out.println("Product of " + num1 + " and " + num2 + " is " + (num1 * num2));
                    break;
                default:
                    System.out.println("Invalid operator! Use +, -, or *.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter valid integers for <num1> and <num2>.");
        }
    }
} 