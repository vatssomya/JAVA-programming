/*Additional Question:
1. Write a program to calculate the final grade of a student based on the marks entered in
three subjects. Use the following grading scale:
Average >= 90: Grade A
Average >= 75: Grade B
Average >= 50: Grade C
Otherwise: Grade F
2. WAP to Take input as DD MM YYYY(04 08 2021) in command line and calculate number
of days since 1 January 1970public class qadditional {
    
}
*/