/*5. Create a program that accepts three integers and determines the greatest among them
using nested if-else statements
public class q5 {
    
}
*/