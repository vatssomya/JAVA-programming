public class q2 {
    
    static double simpleinterest(double t, double r, double p){
        return (t * r * p);
    }
    public static void main(String[] args) throws Exception {

        double time = 3;
        double rate = 4;
        double principle = 50000;

        double interest = simpleinterest(time, rate, principle);
        System.out.println("Total interest: " + interest);
        
    }
}
